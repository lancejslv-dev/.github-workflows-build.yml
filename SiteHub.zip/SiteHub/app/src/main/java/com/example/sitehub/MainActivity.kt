package com.example.sitehub

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {

    private lateinit var db: Db
    private lateinit var root: FrameLayout
    private lateinit var webX: WebView
    private lateinit var webFb: WebView
    private lateinit var pane: View
    private lateinit var pathTitle: TextView
    private lateinit var emptyText: TextView
    private lateinit var list: ListView
    private lateinit var btnNewFolder: Button
    private lateinit var fab: FloatingActionButton
    private lateinit var nav: BottomNavigationView

    private var currentFolder: Folder? = null
    private var folderEntries: List<Folder> = emptyList()
    private var bmEntries: List<Bookmark> = emptyList()

    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        db = Db(this)

        root = findViewById(R.id.root)
        webX = findViewById(R.id.webX)
        webFb = findViewById(R.id.webFb)
        pane = findViewById(R.id.bookmarksPane)
        pathTitle = findViewById(R.id.pathTitle)
        emptyText = findViewById(R.id.emptyText)
        list = findViewById(R.id.list)
        btnNewFolder = findViewById(R.id.btnNewFolder)
        fab = findViewById(R.id.fab)
        nav = findViewById(R.id.nav)

        setupWeb(webX, "https://x.com")
        setupWeb(webFb, "https://m.facebook.com")

        nav.setOnItemSelectedListener { show(it.itemId); true }
        list.setOnItemClickListener { _, _, pos, _ -> onEntryClick(pos) }
        list.setOnItemLongClickListener { _, _, pos, _ -> onEntryLongClick(pos); true }
        btnNewFolder.setOnClickListener {
            askName("New folder") { name -> db.addFolder(name); refresh() }
        }
        fab.setOnClickListener { saveBookmark() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    customView != null -> hideCustom()
                    nav.selectedItemId == R.id.nav_bm -> {
                        if (currentFolder != null) { currentFolder = null; refresh() } else finish()
                    }
                    currentWeb().canGoBack() -> currentWeb().goBack()
                    else -> finish()
                }
            }
        })

        show(R.id.nav_x)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWeb(web: WebView, url: String) {
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.userAgentString = s.userAgentString.replace("; wv", "")
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View, callback: WebChromeClient.CustomViewCallback) {
                if (customView != null) { callback.onCustomViewHidden(); return }
                customView = view
                customCb = callback
                root.addView(
                    view,
                    ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                )
                WindowInsetsControllerCompat(window, window.decorView).hide(WindowInsetsCompat.Type.systemBars())
            }

            override fun onHideCustomView() { hideCustom() }
        }
        web.loadUrl(url)
    }

    private fun hideCustom() {
        customView?.let { root.removeView(it) }
        customView = null
        val cb = customCb
        customCb = null
        cb?.onCustomViewHidden()
        WindowInsetsControllerCompat(window, window.decorView).show(WindowInsetsCompat.Type.systemBars())
    }

    private fun currentWeb(): WebView =
        if (nav.selectedItemId == R.id.nav_fb) webFb else webX

    private fun show(id: Int) {
        webX.visibility = if (id == R.id.nav_x) View.VISIBLE else View.GONE
        webFb.visibility = if (id == R.id.nav_fb) View.VISIBLE else View.GONE
        pane.visibility = if (id == R.id.nav_bm) View.VISIBLE else View.GONE
        fab.visibility = if (id == R.id.nav_bm) View.GONE else View.VISIBLE
        if (id == R.id.nav_bm) refresh()
    }

    private fun refresh() {
        val f = currentFolder
        if (f == null) {
            folderEntries = db.folders()
            pathTitle.text = "Folders"
            btnNewFolder.visibility = View.VISIBLE
            list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, folderEntries.map { "\uD83D\uDCC1  ${it.name}" })
            emptyText.text = "No folders yet. Tap New folder, or bookmark a page with the star button."
            emptyText.visibility = if (folderEntries.isEmpty()) View.VISIBLE else View.GONE
        } else {
            bmEntries = db.bookmarks(f.id)
            pathTitle.text = "\uD83D\uDCC1  ${f.name}"
            btnNewFolder.visibility = View.GONE
            list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, bmEntries.map { it.title })
            emptyText.text = "This folder is empty."
            emptyText.visibility = if (bmEntries.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    private fun onEntryClick(pos: Int) {
        if (currentFolder == null) {
            currentFolder = folderEntries.getOrNull(pos)
            refresh()
        } else {
            bmEntries.getOrNull(pos)?.let { openBookmark(it) }
        }
    }

    private fun onEntryLongClick(pos: Int) {
        if (currentFolder == null) {
            val f = folderEntries.getOrNull(pos) ?: return
            confirm("Delete folder \"${f.name}\" and everything in it?") { db.deleteFolder(f.id); refresh() }
        } else {
            val b = bmEntries.getOrNull(pos) ?: return
            confirm("Delete this bookmark?") { db.deleteBookmark(b.id); refresh() }
        }
    }

    private fun openBookmark(b: Bookmark) {
        val isFb = b.url.contains("facebook.com") || b.url.contains("fb.watch") || b.url.contains("fb.com")
        nav.selectedItemId = if (isFb) R.id.nav_fb else R.id.nav_x
        currentWeb().loadUrl(b.url)
    }

    private fun saveBookmark() {
        val web = currentWeb()
        val url = web.url ?: return
        val title = (web.title ?: "").ifBlank { url }
        val folders = db.folders()
        val labels = folders.map { it.name } + "\u2795  New folder"
        AlertDialog.Builder(this)
            .setTitle("Save to folder")
            .setItems(labels.toTypedArray()) { _, which ->
                if (which < folders.size) {
                    db.addBookmark(folders[which].id, title, url)
                    Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
                } else {
                    askName("New folder") { name ->
                        val id = db.addFolder(name)
                        db.addBookmark(id, title, url)
                        Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .show()
    }

    private fun askName(title: String, onOk: (String) -> Unit) {
        val input = EditText(this)
        input.hint = "Name"
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(input)
            .setPositiveButton("OK") { _, _ ->
                val n = input.text.toString().trim()
                if (n.isNotEmpty()) onOk(n)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun confirm(msg: String, onYes: () -> Unit) {
        AlertDialog.Builder(this)
            .setMessage(msg)
            .setPositiveButton("Delete") { _, _ -> onYes() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onPause() {
        super.onPause()
        CookieManager.getInstance().flush()
    }
}
