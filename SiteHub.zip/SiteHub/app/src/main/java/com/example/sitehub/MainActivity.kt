package com.example.sitehub

import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoView

class Tab(val view: GeckoView, val session: GeckoSession) {
    var url: String? = null
    var title: String? = null
    var canGoBack = false
}

class MainActivity : AppCompatActivity() {

    companion object {
        private var sRuntime: GeckoRuntime? = null
    }

    private lateinit var db: Db
    private lateinit var tabX: Tab
    private lateinit var tabFb: Tab
    private lateinit var tabP: Tab
    private lateinit var playerBox: View
    private lateinit var playerTitle: TextView
    private lateinit var pane: View
    private lateinit var pathTitle: TextView
    private lateinit var emptyText: TextView
    private lateinit var list: ListView
    private lateinit var btnNewFolder: Button
    private lateinit var fab: FloatingActionButton
    private lateinit var nav: BottomNavigationView

    private var currentFolder: Folder? = null
    private var folderEntries: List<Folder> = emptyList()
    private var bmEntries: List<Bookmark> = emptyList()
    private var isFullScreen = false
    private var fsTab: Tab? = null
    private var playing: Bookmark? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        db = Db(this)

        pane = findViewById(R.id.bookmarksPane)
        playerBox = findViewById(R.id.playerBox)
        playerTitle = findViewById(R.id.playerTitle)
        pathTitle = findViewById(R.id.pathTitle)
        emptyText = findViewById(R.id.emptyText)
        list = findViewById(R.id.list)
        btnNewFolder = findViewById(R.id.btnNewFolder)
        fab = findViewById(R.id.fab)
        nav = findViewById(R.id.nav)

        tabX = setupTab(findViewById(R.id.geckoX), "https://x.com")
        tabFb = setupTab(findViewById(R.id.geckoFb), "https://www.facebook.com")
        tabP = setupTab(findViewById(R.id.geckoPlayer), "about:blank")
        tabP.session.setActive(false)

        nav.setOnItemSelectedListener { show(it.itemId); true }
        list.setOnItemClickListener { _, _, pos, _ -> onEntryClick(pos) }
        list.setOnItemLongClickListener { _, _, pos, _ -> onEntryLongClick(pos); true }
        btnNewFolder.setOnClickListener {
            askName("New folder") { name -> db.addFolder(name); refresh() }
        }
        fab.setOnClickListener { saveBookmark() }
        findViewById<Button>(R.id.btnClosePlayer).setOnClickListener { closePlayer() }
        findViewById<Button>(R.id.btnOpenPage).setOnClickListener {
            playing?.let { openBookmark(it) }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    isFullScreen -> fsTab?.session?.exitFullScreen()
                    nav.selectedItemId == R.id.nav_bm -> {
                        if (playing != null) closePlayer()
                        else if (currentFolder != null) { currentFolder = null; refresh() } else finish()
                    }
                    currentTab().canGoBack -> currentTab().session.goBack()
                    else -> finish()
                }
            }
        })

        show(R.id.nav_x)
    }

    private fun runtime(): GeckoRuntime {
        return sRuntime ?: GeckoRuntime.create(applicationContext).also { sRuntime = it }
    }

    private fun setupTab(view: GeckoView, startUrl: String): Tab {
        val session = GeckoSession()
        val tab = Tab(view, session)

        session.navigationDelegate = object : GeckoSession.NavigationDelegate {
            override fun onLocationChange(
                session: GeckoSession,
                url: String?,
                perms: MutableList<GeckoSession.PermissionDelegate.ContentPermission>,
                hasUserGesture: Boolean
            ) {
                tab.url = url
            }

            override fun onCanGoBack(session: GeckoSession, canGoBack: Boolean) {
                tab.canGoBack = canGoBack
            }

            override fun onNewSession(session: GeckoSession, uri: String): GeckoResult<GeckoSession>? {
                view.post { tab.session.loadUri(uri) }
                return null
            }
        }

        session.contentDelegate = object : GeckoSession.ContentDelegate {
            override fun onTitleChange(session: GeckoSession, title: String?) {
                tab.title = title
            }

            override fun onFullScreen(session: GeckoSession, fullScreen: Boolean) {
                setFullScreen(fullScreen, tab)
            }
        }

        session.open(runtime())
        view.setSession(session)
        session.loadUri(startUrl)
        return tab
    }

    private fun setFullScreen(on: Boolean, tab: Tab) {
        isFullScreen = on
        fsTab = if (on) tab else null
        nav.visibility = if (on) View.GONE else View.VISIBLE
        fab.visibility = if (on || nav.selectedItemId == R.id.nav_bm) View.GONE else View.VISIBLE
        val c = WindowInsetsControllerCompat(window, window.decorView)
        if (on) c.hide(WindowInsetsCompat.Type.systemBars()) else c.show(WindowInsetsCompat.Type.systemBars())
    }

    private fun currentTab(): Tab =
        if (nav.selectedItemId == R.id.nav_fb) tabFb else tabX

    private fun show(id: Int) {
        tabX.view.visibility = if (id == R.id.nav_x) View.VISIBLE else View.GONE
        tabFb.view.visibility = if (id == R.id.nav_fb) View.VISIBLE else View.GONE
        tabX.session.setActive(id == R.id.nav_x)
        tabFb.session.setActive(id == R.id.nav_fb)
        pane.visibility = if (id == R.id.nav_bm) View.VISIBLE else View.GONE
        fab.visibility = if (id == R.id.nav_bm) View.GONE else View.VISIBLE
        if (id == R.id.nav_bm) refresh() else closePlayer()
    }

    private fun refresh() {
        val f = currentFolder
        if (f == null) {
            folderEntries = db.folders()
            pathTitle.text = "Folders"
            btnNewFolder.visibility = View.VISIBLE
            list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, folderEntries.map { "\uD83D\uDCC1  ${it.name}" })
            emptyText.text = "No folders yet. Tap New folder, or bookmark a page with the star button."
            emptyText.visibility = if (folderEntries.isEmpty()) View.VISIBLE else View.GONE
        } else {
            bmEntries = db.bookmarks(f.id)
            pathTitle.text = "\uD83D\uDCC1  ${f.name}"
            btnNewFolder.visibility = View.GONE
            list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, bmEntries.map { it.title })
            emptyText.text = "This folder is empty."
            emptyText.visibility = if (bmEntries.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    private fun onEntryClick(pos: Int) {
        if (currentFolder == null) {
            currentFolder = folderEntries.getOrNull(pos)
            refresh()
        } else {
            bmEntries.getOrNull(pos)?.let { playBookmark(it) }
        }
    }

    private fun onEntryLongClick(pos: Int) {
        if (currentFolder == null) {
            val f = folderEntries.getOrNull(pos) ?: return
            confirm("Delete folder \"${f.name}\" and everything in it?") { db.deleteFolder(f.id); refresh() }
        } else {
            val b = bmEntries.getOrNull(pos) ?: return
            confirm("Delete this bookmark?") { db.deleteBookmark(b.id); refresh() }
        }
    }

    private fun embedUrl(url: String): String {
        val u = url.lowercase()
        val tw = Regex("(?:x|twitter)\\.com/[^/]+/status/(\\d+)").find(u)
        if (tw != null) {
            return "https://platform.twitter.com/embed/Tweet.html?id=${tw.groupValues[1]}&theme=dark"
        }
        val isFb = u.contains("facebook.com") || u.contains("fb.watch")
        if (isFb && (u.contains("/videos/") || u.contains("/watch") || u.contains("/reel") || u.contains("fb.watch"))) {
            return "https://www.facebook.com/plugins/video.php?href=" + Uri.encode(url) + "&show_text=false"
        }
        return url
    }

    private fun playBookmark(b: Bookmark) {
        playing = b
        playerTitle.text = b.title
        playerBox.visibility = View.VISIBLE
        tabP.session.setActive(true)
        tabP.session.loadUri(embedUrl(b.url))
    }

    private fun closePlayer() {
        playing = null
        tabP.session.loadUri("about:blank")
        tabP.session.setActive(false)
        playerBox.visibility = View.GONE
    }

    private fun openBookmark(b: Bookmark) {
        val isFb = b.url.contains("facebook.com") || b.url.contains("fb.watch") || b.url.contains("fb.com")
        nav.selectedItemId = if (isFb) R.id.nav_fb else R.id.nav_x
        currentTab().session.loadUri(b.url)
    }

    private fun saveBookmark() {
        val tab = currentTab()
        val url = tab.url ?: return
        val title = (tab.title ?: "").ifBlank { url }
        val folders = db.folders()
        val labels = folders.map { it.name } + "\u2795  New folder"
        AlertDialog.Builder(this)
            .setTitle("Save to folder")
            .setItems(labels.toTypedArray()) { _, which ->
                if (which < folders.size) {
                    db.addBookmark(folders[which].id, title, url)
                    Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
                } else {
                    askName("New folder") { name ->
                        val id = db.addFolder(name)
                        db.addBookmark(id, title, url)
                        Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .show()
    }

    private fun askName(title: String, onOk: (String) -> Unit) {
        val input = EditText(this)
        input.hint = "Name"
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(input)
            .setPositiveButton("OK") { _, _ ->
                val n = input.text.toString().trim()
                if (n.isNotEmpty()) onOk(n)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun confirm(msg: String, onYes: () -> Unit) {
        AlertDialog.Builder(this)
            .setMessage(msg)
            .setPositiveButton("Delete") { _, _ -> onYes() }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
