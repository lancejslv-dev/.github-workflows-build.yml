package com.example.sitehub

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Folder(val id: Long, val name: String)
data class Bookmark(val id: Long, val folderId: Long, val title: String, val url: String)

class Db(ctx: Context) : SQLiteOpenHelper(ctx, "hub.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE folders(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL)")
        db.execSQL("CREATE TABLE bookmarks(id INTEGER PRIMARY KEY AUTOINCREMENT, folder_id INTEGER NOT NULL, title TEXT NOT NULL, url TEXT NOT NULL)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun folders(): List<Folder> {
        val out = mutableListOf<Folder>()
        readableDatabase.rawQuery("SELECT id, name FROM folders ORDER BY name COLLATE NOCASE", null).use { c ->
            while (c.moveToNext()) out.add(Folder(c.getLong(0), c.getString(1)))
        }
        return out
    }

    fun addFolder(name: String): Long {
        val v = ContentValues().apply { put("name", name) }
        return writableDatabase.insert("folders", null, v)
    }

    fun deleteFolder(id: Long) {
        writableDatabase.delete("bookmarks", "folder_id=?", arrayOf(id.toString()))
        writableDatabase.delete("folders", "id=?", arrayOf(id.toString()))
    }

    fun bookmarks(folderId: Long): List<Bookmark> {
        val out = mutableListOf<Bookmark>()
        readableDatabase.rawQuery(
            "SELECT id, folder_id, title, url FROM bookmarks WHERE folder_id=? ORDER BY id DESC",
            arrayOf(folderId.toString())
        ).use { c ->
            while (c.moveToNext()) out.add(Bookmark(c.getLong(0), c.getLong(1), c.getString(2), c.getString(3)))
        }
        return out
    }

    fun addBookmark(folderId: Long, title: String, url: String) {
        val v = ContentValues().apply {
            put("folder_id", folderId); put("title", title); put("url", url)
        }
        writableDatabase.insert("bookmarks", null, v)
    }

    fun deleteBookmark(id: Long) {
        writableDatabase.delete("bookmarks", "id=?", arrayOf(id.toString()))
    }
}
